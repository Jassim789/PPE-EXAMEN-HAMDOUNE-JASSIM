<h3 class="titre-form">Ajouter : Centre</h3>

<form method="post" class="formulaire">
    <table>
        <tr>
            <td>Nom du centre :</td>
            <td><input type="text" name="NomCentre"></td>
        </tr>
        <tr>
            <td>Adresse :</td>
            <td><input type="text" name="AdresseCentre"></td>
        </tr>
        <tr>
            <td>Code postal :</td>
            <td><input type="text" name="CPCentre"></td>
        </tr>
        <tr>
            <td>Ville :</td>
            <td><input type="text" name="VilleCentre"></td>
        </tr>
        <tr>
            <td>Téléphone :</td>
            <td><input type="text" name="TelCentre"></td>
        </tr>
        <tr>
            <td>Gérant :</td>
            <td><select name="IdGerant"><option value="">-- Aucun --</option><?php mysqli_data_seek($lesUtilisateurs, 0); foreach ($lesUtilisateurs as $ligneFk) { echo "<option value='".$ligneFk['IdUtilisateur']."'>".('#'.$ligneFk['IdUtilisateur'].' - '.$ligneFk['PseudonymeUtilisateur'])."</option>"; } ?></select></td>
        </tr>
        <tr>
            <td><input type="reset" name="Annuler" value="Annuler"></td>
            <td><input type="submit" name="Valider" value="Valider"></td>
        </tr>
    </table>
</form>
