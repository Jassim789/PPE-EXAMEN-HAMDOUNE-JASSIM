<h3 class="titre-form">Liste des Box</h3>

<table class="tableau">
    <tr>
        <th>ID</th>
        <th>Numéro du box</th>
        <th>Cheval (occupant)</th>
        <th>Type de logement</th>
        <th>Centre</th>
        <th>Date d'ajout</th>
        <?php if ($peutModifier) { ?><th>Actions</th><?php } ?>
    </tr>

    <?php
    mysqli_data_seek($lesLignes, 0);
    foreach ($lesLignes as $ligne) {
        echo "<tr>";
            echo "<td>".htmlspecialchars($ligne['IdBox'] ?? '')."</td>";
            echo "<td>".htmlspecialchars($ligne['NumBox'] ?? '')."</td>";
            echo "<td>".htmlspecialchars($ligne['IdCheval'] ?? '')."</td>";
            echo "<td>".htmlspecialchars($ligne['IdTypeLogement'] ?? '')."</td>";
            echo "<td>".htmlspecialchars($ligne['IdCentre'] ?? '')."</td>";
            echo "<td>".htmlspecialchars($ligne['DateAjoutBox'] ?? '')."</td>";
        if ($peutModifier) {
            echo "<td class='actions'>";
            echo "<a href='index.php?page=4&action=edit&IdBox=".urlencode($ligne['IdBox'])."' title='Modifier'>&#9998;</a> ";
            echo "<a href='index.php?page=4&action=sup&IdBox=".urlencode($ligne['IdBox'])."' title='Supprimer' onclick=\"return confirm('Confirmer la suppression ?');\">&#128465;</a>";
            echo "</td>";
        }
        echo "</tr>";
    }
    ?>
</table>
